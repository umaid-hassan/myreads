import App from './App.js';

export default App;