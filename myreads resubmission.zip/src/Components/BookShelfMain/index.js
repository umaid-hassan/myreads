import BookShelfMain from './BookShelfMain.js';

export default BookShelfMain;