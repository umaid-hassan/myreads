import Book from './Book.js';

export default Book;