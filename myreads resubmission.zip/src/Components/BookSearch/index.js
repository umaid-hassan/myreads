import BookSearch from './BookSearch.js';

export default BookSearch;