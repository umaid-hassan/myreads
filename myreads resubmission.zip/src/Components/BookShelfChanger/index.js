import BookShelfChanger from './BookShelfChanger.js';

export default BookShelfChanger;